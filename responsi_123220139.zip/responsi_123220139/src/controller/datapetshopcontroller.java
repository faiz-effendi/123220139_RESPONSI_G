package controller;

import java.util.List;
import DAOdatapetshop.datapetshopDAO;
import model.*;
import DAOImplement.datapetshopimplement;
import view.MainView;

public class datapetshopcontroller {
    MainView frame;
    datapetshopimplement impldatapetshop;
    List<datapetshop> dp;
    
    public datapetshopcontroller(MainView frame){
        this.frame = frame;
        impldatapetshop = new datapetshopDAO();
        dp = impldatapetshop.getAll();
    }
    
    public void isitabel(){
        dp = impldatapetshop.getAll();
        modeltabeldatapetshop mp = new modeltabeldatapetshop(dp);
        frame.getTabelData().setModel(mp);
    }
    
    public void insert(){
        Integer durasi = Integer.parseInt(frame.getJTxtdurasititip().getText());
        Integer total_biaya;
        
        if(durasi > 2){
            durasi -= 2;
            total_biaya = (2*100000)+(durasi*50000);
        }else{
            total_biaya = durasi*100000;
        }
        
        datapetshop dp = new datapetshop();
        
        dp.setNamapemilik(frame.getJTxtnamapemilik().getText());
        dp.setNamahewan(frame.getJTxtnamahewan().getText());
        dp.setJenishewan(frame.getJTxtjenishewan().getText());
        dp.setNomortelepon(frame.getJTxtnomortelepon().getText());
        dp.setDurasi(Integer.parseInt(frame.getJTxtdurasititip().getText()));
        dp.setTotalbiaya(total_biaya);
        
        impldatapetshop.insert(dp);
    }
    
    public void delete(){
        Integer id = Integer.parseInt(frame.getJTxtid().getText());
        impldatapetshop.delete(id);
    }
}

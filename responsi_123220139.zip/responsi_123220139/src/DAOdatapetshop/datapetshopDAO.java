package DAOdatapetshop;

import java.sql.*;
import java.util.*;
import koneksi.connector;
import model.*;
import DAOImplement.datapetshopimplement;
import java.util.logging.Level;
import java.util.logging.Logger;

public class datapetshopDAO implements datapetshopimplement{
    Connection connection;
    
    final String select = "SELECT * FROM titip_hewan";
    final String insert = "INSERT INTO titip_hewan (nama_pemilik, nama_hewan, jenis_hewan, nomor_telepon, durasi_titip, total_biaya) "
                            + "VALUES (?, ?, ?, ?, ?, ?)";
    final String delete = "DELETE FROM titip_hewan WHERE id=?";
    
    public datapetshopDAO(){
        connection = connector.connection();
    }

    @Override
    public void insert(datapetshop p) {
        PreparedStatement statement = null;
        
        try{
            statement = connection.prepareStatement(insert, Statement.RETURN_GENERATED_KEYS);
            statement.setString(1, p.getNamapemilik());
            statement.setString(2, p.getNamahewan());
            statement.setString(3, p.getJenishewan());
            statement.setString(4, p.getNomortelepon());
            statement.setInt(5, p.getDurasi());
            statement.setInt(6, p.getTotalbiaya());
            ResultSet rs = statement.getGeneratedKeys();
            while(rs.next()){
                p.setId(rs.getInt(1));
            }
            statement.executeUpdate();
            
        }catch(SQLException ex){
            ex.printStackTrace();
        }finally{
            try{
                statement.close();
            }catch(SQLException ex){
                ex.printStackTrace();
            }
        }
    }

    @Override
    public void update(datapetshop p) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void delete(int id) {
        PreparedStatement statement = null;
        
        try{
            statement = connection.prepareStatement(delete);
            
            statement.setInt(1, id);
            statement.executeUpdate();
        }catch(SQLException ex){
            ex.printStackTrace();
        }
    }

    @Override
    public List<datapetshop> getAll() {
        List<datapetshop> dp = null;
        try{
            dp = new ArrayList<datapetshop>();
            Statement st = connection.createStatement();
            ResultSet rs = st.executeQuery(select);
            while(rs.next()){
                datapetshop datap = new datapetshop();
                datap.setId(rs.getInt("id"));
                datap.setNamapemilik(rs.getString("nama_pemilik"));
                datap.setNamahewan(rs.getString("nama_hewan"));
                datap.setJenishewan(rs.getString("jenis_hewan"));
                datap.setNomortelepon(rs.getString("nomor_telepon"));
                datap.setDurasi(rs.getInt("durasi_titip"));
                datap.setTotalbiaya(rs.getInt("total_biaya"));
                
                dp.add(datap);
            }
        }catch(SQLException ex){
            Logger.getLogger(datapetshopDAO.class.getName()).log(Level.SEVERE,null,ex);
        }
        return dp;
    }
}

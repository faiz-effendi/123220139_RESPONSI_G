package DAOImplement;

import java.util.List;
import model.*;

public interface datapetshopimplement {
    public void insert(datapetshop p);
    public void update(datapetshop p);
    public void delete(int id);
    public List<datapetshop> getAll();
}

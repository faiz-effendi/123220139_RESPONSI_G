package model;

public class datapetshop {
    private Integer id;
    private String namapemilik;
    private String namahewan;
    private String jenishewan;
    private String nomortelepon;
    private Integer durasi;
    private Integer totalbiaya;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNamapemilik() {
        return namapemilik;
    }

    public void setNamapemilik(String namapemilik) {
        this.namapemilik = namapemilik;
    }

    public String getNamahewan() {
        return namahewan;
    }

    public void setNamahewan(String namahewan) {
        this.namahewan = namahewan;
    }

    public String getJenishewan() {
        return jenishewan;
    }

    public void setJenishewan(String jenishewan) {
        this.jenishewan = jenishewan;
    }

    public String getNomortelepon() {
        return nomortelepon;
    }

    public void setNomortelepon(String nomortelepon) {
        this.nomortelepon = nomortelepon;
    }

    public Integer getDurasi() {
        return durasi;
    }

    public void setDurasi(Integer durasi) {
        this.durasi = durasi;
    }

    public Integer getTotalbiaya() {
        return totalbiaya;
    }

    public void setTotalbiaya(Integer totalbiaya) {
        this.totalbiaya = totalbiaya;
    }
    
    
}

package model;

import java.util.List;
import javax.swing.table.AbstractTableModel;

public class modeltabeldatapetshop extends AbstractTableModel{
    List<datapetshop> dp;
    public modeltabeldatapetshop(List<datapetshop> dp){
        this.dp = dp;
    }

    @Override
    public int getRowCount() {
        return dp.size(); // auto hitung size data
    }

    @Override
    public int getColumnCount() {
        return 7; // banyak kolom = 7
    }

    @Override
    public String getColumnName(int column){
        switch(column){
            case 0 :
                return "ID";
            case 1 :
                return "Nama Pemilik";    
            case 2 :
                return "Nama Hewan";
            case 3 :
                return "Jenis Hewan";
            case 4 :
                return "Nomor Telepon";
            case 5 :
                return "Durasi Penitipan";
            case 6 :
                return "Total Biaya";
            default :
                return null;
        }
    }
    
    @Override
    public Object getValueAt(int row, int column) {
        switch(column){
            case 0 :
                return dp.get(row).getId();
            case 1 :
                return dp.get(row).getNamapemilik();
            case 2 :
                return dp.get(row).getNamahewan();
            case 3 :
                return dp.get(row).getJenishewan();
            case 4 :
                return dp.get(row).getNomortelepon();
            case 5 :
                return dp.get(row).getDurasi();
            case 6 :
                return dp.get(row).getTotalbiaya();
            default :
                return null;
        }
    }
}
